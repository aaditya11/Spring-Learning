package com.example.JpaHw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaHwApplicationTests {

	@Test
	void contextLoads() {
	}

}
