package com.example.JpaHw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaHwApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaHwApplication.class, args);
	}

}
